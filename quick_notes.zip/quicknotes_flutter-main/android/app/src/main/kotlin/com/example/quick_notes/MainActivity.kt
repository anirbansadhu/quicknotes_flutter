package com.example.quick_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
